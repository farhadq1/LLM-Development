# Guia de Migração Java → Python

## Resumo da Conversão

Este documento explica como o projeto ARX foi convertido de Java para Python, mantendo a funcionalidade essencial do `Example43.java`.

## Principais Mudanças

### 1. Estrutura de Classes

**Java Original:**
```java
// Importações
import org.deidentifier.arx.Data;
import org.deidentifier.arx.AttributeType.Hierarchy;

// Criação de dados
DefaultData data = Data.create();
data.add("age", "gender", "zipcode");

// Hierarquias
DefaultHierarchy age = Hierarchy.create();
age.add("34", "<50", "*");
```

**Python Convertido:**
```python
# Importações
from arx_anonymizer import Data, Hierarchy

# Criação de dados
data = Data.create()
data.add("age", "gender", "zipcode")

# Hierarquias
age = Hierarchy.create()
age.add("34", "<50", "*")
```

### 2. Convenções de Nomenclatura

| Java (camelCase) | Python (snake_case) |
|------------------|---------------------|
| `getDefinition()` | `get_definition()` |
| `setAttributeType()` | `set_attribute_type()` |
| `getRiskEstimator()` | `get_risk_estimator()` |
| `getSampleBasedRiskSummary()` | `get_sample_based_risk_summary()` |

### 3. Estrutura de Dados

**Java:** Usa estruturas internas do ARX
```java
DataHandle handle = data.getHandle();
Iterator<String[]> iterator = handle.iterator();
```

**Python:** Usa pandas DataFrame internamente
```python
handle = data.get_handle()
# Internamente usa pandas.DataFrame para eficiência
for row in handle.iterator():
    print(row)
```

### 4. Tratamento de Tipos

**Java:** Tipagem estática obrigatória
```java
double THRESHOLD = 0.5d;
RiskModelSampleSummary risks = builder.getSampleBasedRiskSummary(THRESHOLD);
```

**Python:** Tipagem opcional com type hints
```python
THRESHOLD: float = 0.5
risks: RiskModelSampleSummary = builder.get_sample_based_risk_summary(THRESHOLD)
```

## Arquitetura Convertida

### Módulos Python Criados

1. **`arx_anonymizer/data.py`**
   - Classes: `Data`, `DataHandle`, `DataDefinition`, `DefaultData`
   - Equivalente a: `org.deidentifier.arx.Data.*`

2. **`arx_anonymizer/attribute_type.py`**
   - Classes: `AttributeType`, `Hierarchy`
   - Equivalente a: `org.deidentifier.arx.AttributeType.*`

3. **`arx_anonymizer/population_model.py`**
   - Classe: `ARXPopulationModel`
   - Equivalente a: `org.deidentifier.arx.ARXPopulationModel`

4. **`arx_anonymizer/risk/`**
   - Classes: `RiskEstimateBuilder`, `RiskModelSampleSummary`, `AttackerRisk`
   - Equivalente a: `org.deidentifier.arx.risk.*`

### Dependências

**Java:** ARX library + dependências Maven
```xml
<dependency>
    <groupId>org.deidentifier.arx</groupId>
    <artifactId>arx</artifactId>
</dependency>
```

**Python:** Bibliotecas científicas
```txt
pandas>=1.5.0
numpy>=1.20.0
scipy>=1.8.0
```

## Exemplo de Uso Comparativo

### Java Original (Example43.java)
```java
public class Example43 {
    public static void main(String[] args) throws IOException {
        DefaultData data = Data.create();
        data.add("age", "gender", "zipcode");
        // ... adicionar dados
        
        DefaultHierarchy age = Hierarchy.create();
        age.add("34", "<50", "*");
        // ... definir hierarquias
        
        data.getDefinition().setAttributeType("age", age);
        
        ARXPopulationModel populationmodel = ARXPopulationModel.create(Region.USA);
        RiskEstimateBuilder builder = handle.getRiskEstimator(populationmodel);
        RiskModelSampleSummary risks = builder.getSampleBasedRiskSummary(0.5);
        
        System.out.println("Records at risk: " + getPrecent(risks.getProsecutorRisk().getRecordsAtRisk()));
    }
}
```

### Python Convertido (example43.py)
```python
class Example43:
    @staticmethod
    def main():
        data = Data.create()
        data.add("age", "gender", "zipcode")
        # ... adicionar dados
        
        age = Hierarchy.create()
        age.add("34", "<50", "*")
        # ... definir hierarquias
        
        data.get_definition().set_attribute_type("age", age)
        
        population_model = ARXPopulationModel.create(ARXPopulationModel.Region.USA)
        builder = handle.get_risk_estimator(population_model)
        risks = builder.get_sample_based_risk_summary(0.5)
        
        print(f"Records at risk: {Example43.get_percent(risks.get_prosecutor_risk().get_records_at_risk())}")

if __name__ == "__main__":
    Example43.main()
```

## Benefícios da Versão Python

1. **Sintaxe mais limpa**: Menos boilerplate code
2. **Pandas integration**: Manipulação eficiente de dados tabulares
3. **Type hints**: Documentação de tipos opcional
4. **Ecosystem**: Acesso ao rico ecossistema científico Python
5. **Interactive development**: Jupyter notebooks, IPython

## Limitações Atuais

A versão Python implementa o core do Example43, mas não inclui:
- Interface gráfica completa
- Algoritmos de anonimização avançados
- Todos os critérios de privacidade (k-anonymity, l-diversity, etc.)
- Importação/exportação de múltiplos formatos

## Próximos Passos

Para expandir a funcionalidade:

1. **Implementar algoritmos de anonimização:**
```python
from arx_anonymizer import ARXAnonymizer, ARXConfiguration
from arx_anonymizer.criteria import KAnonymity

anonymizer = ARXAnonymizer()
config = ARXConfiguration.create()
config.add_privacy_model(KAnonymity(2))
result = anonymizer.anonymize(data, config)
```

2. **Adicionar suporte a mais formatos de dados:**
```python
# CSV, Excel, JSON, etc.
data = Data.load_csv("dataset.csv")
data.save_excel("anonymized_dataset.xlsx")
```

3. **Interface para Jupyter:**
```python
# Visualização interativa
data.visualize_risk_analysis()
data.plot_hierarchy("age")
```

## Execução

```bash
# Instalar dependências
cd python_version
pip install -r requirements.txt

# Executar exemplo
python examples/example43.py

# Ou usar script de teste
python run_example.py
```
