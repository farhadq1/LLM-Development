# ARX Data Anonymization Tool - Python Version

Esta é uma conversão do ARX Data Anonymization Tool de Java para Python, mantendo a funcionalidade principal de análise de risco de dados.

## Estrutura do Projeto

```
python_version/
├── arx_anonymizer/          # Módulo principal
│   ├── __init__.py         # Imports principais
│   ├── data.py             # Classes de manipulação de dados
│   ├── attribute_type.py   # Tipos de atributos e hierarquias
│   ├── population_model.py # Modelos populacionais
│   └── risk/               # Módulo de análise de risco
│       └── __init__.py     # Classes de estimativa de risco
├── examples/               # Exemplos de uso
│   └── example43.py       # Exemplo principal (convertido do Java)
├── data/                  # Dados de exemplo
└── requirements.txt       # Dependências Python
```

## Instalação

1. **Instalar dependências:**
```bash
cd python_version
pip install -r requirements.txt
```

2. **Executar o exemplo:**
```bash
cd python_version
python examples/example43.py
```

## Principais Classes Convertidas

### Data e DataHandle
- `Data.create()`: Cria uma nova instância de dados
- `DataHandle`: Handle para manipular e analisar dados
- `DataDefinition`: Define tipos de atributos

### AttributeType e Hierarchy
- `Hierarchy.create()`: Cria hierarquias de generalização
- `DefaultHierarchy.add()`: Adiciona níveis hierárquicos

### ARXPopulationModel
- `ARXPopulationModel.create(Region)`: Cria modelos populacionais
- Suporte para regiões: USA, EUROPE, WORLD

### Risk Analysis
- `RiskEstimateBuilder`: Constrói estimativas de risco
- `RiskModelSampleSummary`: Sumário de métricas de risco
- `AttackerRisk`: Métricas específicas por tipo de atacante

## Modelos de Atacante

O sistema suporta três modelos de atacante:

1. **Prosecutor (Promotor)**: Conhece todos os atributos
2. **Journalist (Jornalista)**: Conhece informações parciais
3. **Marketer**: Usa ataques baseados em população

## Exemplo de Uso

```python
from arx_anonymizer import Data, ARXPopulationModel, Hierarchy

# Criar dados
data = Data.create()
data.add("age", "gender", "zipcode")
data.add("45", "female", "81675")
data.add("34", "male", "81667")

# Definir hierarquias
age = Hierarchy.create()
age.add("34", "<50", "*")
age.add("45", "<50", "*")

# Configurar tipos de atributo
data.get_definition().set_attribute_type("age", age)

# Análise de risco
population_model = ARXPopulationModel.create(ARXPopulationModel.Region.USA)
builder = data.get_handle().get_risk_estimator(population_model)
risks = builder.get_sample_based_risk_summary(0.5)

print(f"Records at risk: {risks.get_prosecutor_risk().get_records_at_risk()}")
```

## Diferenças da Versão Java

1. **Sintaxe Python**: Uso de snake_case ao invés de camelCase
2. **Pandas DataFrames**: Uso de pandas para manipulação de dados
3. **Type Hints**: Tipagem estática opcional para melhor documentação
4. **Simplified API**: API simplificada mantendo funcionalidade essencial

## Dependências

- **pandas**: Manipulação de dados tabulares
- **numpy**: Computação numérica
- **scipy**: Algoritmos científicos
- **matplotlib/seaborn**: Visualização (opcional)

## Limitações Atuais

Esta versão Python implementa as funcionalidades principais do Example43 original:
- Análise de risco básica
- Modelos de atacante
- Hierarquias de generalização

Funcionalidades não implementadas (podem ser adicionadas conforme necessário):
- Algoritmos de anonimização completos
- Interface gráfica
- Importação/exportação de formatos diversos
- Critérios de privacidade avançados (k-anonymity, l-diversity, etc.)

## Extensibilidade

O código foi estruturado de forma modular para facilitar a adição de:
- Novos algoritmos de anonimização
- Critérios de privacidade adicionais
- Suporte a diferentes formatos de dados
- Métricas de risco personalizadas
