"""
Attribute type definitions for ARX anonymization tool.
"""

from typing import List, Dict, Optional, Set
from abc import ABC, abstractmethod


class AttributeType(ABC):
    """Base class for attribute types."""
    pass


class Hierarchy:
    """Hierarchy definition for attributes."""
    
    class DefaultHierarchy:
        """Default implementation of hierarchy."""
        
        def __init__(self):
            self._levels: Dict[str, List[str]] = {}
            self._max_level = 0
        
        def add(self, *levels: str):
            """Add a hierarchy level mapping."""
            if len(levels) < 2:
                raise ValueError("At least two levels required")
            
            base_value = levels[0]
            hierarchy_levels = list(levels[1:])
            self._levels[base_value] = hierarchy_levels
            self._max_level = max(self._max_level, len(hierarchy_levels))
        
        def get_hierarchy(self, value: str) -> Optional[List[str]]:
            """Get hierarchy levels for a value."""
            return self._levels.get(value)
        
        def get_all_values(self) -> Set[str]:
            """Get all base values in this hierarchy."""
            return set(self._levels.keys())
        
        def get_generalized_value(self, value: str, level: int) -> Optional[str]:
            """Get generalized value at specific level."""
            hierarchy = self.get_hierarchy(value)
            if hierarchy and 0 <= level < len(hierarchy):
                return hierarchy[level]
            return None
        
        @property
        def max_level(self) -> int:
            """Get maximum hierarchy level."""
            return self._max_level
    
    @staticmethod
    def create() -> 'Hierarchy.DefaultHierarchy':
        """Create a new default hierarchy."""
        return Hierarchy.DefaultHierarchy()


class IdentifyingAttribute(AttributeType):
    """Identifying attribute type."""
    pass


class SensitiveAttribute(AttributeType):
    """Sensitive attribute type."""
    pass


class QuasiIdentifyingAttribute(AttributeType):
    """Quasi-identifying attribute type."""
    
    def __init__(self, hierarchy: Optional[Hierarchy.DefaultHierarchy] = None):
        self.hierarchy = hierarchy


class InsensitiveAttribute(AttributeType):
    """Insensitive attribute type."""
    pass
