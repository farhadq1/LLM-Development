"""
Data handling module for ARX anonymization tool.
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Iterator
from .attribute_type import AttributeType


class DataDefinition:
    """Definition of data attributes and their types."""
    
    def __init__(self):
        self._attribute_types: Dict[str, AttributeType] = {}
    
    def set_attribute_type(self, attribute: str, attribute_type: AttributeType):
        """Set the type for a specific attribute."""
        self._attribute_types[attribute] = attribute_type
    
    def get_attribute_type(self, attribute: str) -> Optional[AttributeType]:
        """Get the type for a specific attribute."""
        return self._attribute_types.get(attribute)


class DataHandle:
    """Handle for accessing and manipulating data."""
    
    def __init__(self, data: pd.DataFrame, definition: DataDefinition):
        self._data = data.copy()
        self._definition = definition
    
    def get_view(self) -> 'DataView':
        """Get a view of the data."""
        return DataView(self._data)
    
    def get_risk_estimator(self, population_model):
        """Get a risk estimator for this data handle."""
        from .risk import RiskEstimateBuilder
        return RiskEstimateBuilder(self, population_model)
    
    def iterator(self) -> Iterator[List[str]]:
        """Iterate over data rows."""
        for _, row in self._data.iterrows():
            yield row.astype(str).tolist()
    
    @property
    def data(self) -> pd.DataFrame:
        """Get the underlying DataFrame."""
        return self._data


class DataView:
    """View of data for display purposes."""
    
    def __init__(self, data: pd.DataFrame):
        self._data = data
    
    def iterator(self) -> Iterator[List[str]]:
        """Iterate over data rows including header."""
        # First yield the header
        yield self._data.columns.tolist()
        # Then yield the data rows
        for _, row in self._data.iterrows():
            yield row.astype(str).tolist()


class DefaultData:
    """Default implementation of data container."""
    
    def __init__(self):
        self._rows: List[List[str]] = []
        self._definition = DataDefinition()
    
    def add(self, *values: str):
        """Add a row of data."""
        self._rows.append(list(values))
    
    def get_definition(self) -> DataDefinition:
        """Get the data definition."""
        return self._definition
    
    def get_handle(self) -> DataHandle:
        """Get a handle to this data."""
        if not self._rows:
            raise ValueError("No data available")
        
        # First row contains column names
        columns = self._rows[0]
        data_rows = self._rows[1:]
        
        # Create DataFrame
        df = pd.DataFrame(data_rows, columns=columns)
        
        return DataHandle(df, self._definition)


class Data:
    """Factory class for creating data instances."""
    
    @staticmethod
    def create() -> DefaultData:
        """Create a new default data instance."""
        return DefaultData()
