"""
Population model for risk estimation.
"""

from enum import Enum
from typing import Dict, Any


class ARXPopulationModel:
    """Population model for risk analysis."""
    
    class Region(Enum):
        """Supported regions for population models."""
        USA = "USA"
        EUROPE = "EUROPE"
        WORLD = "WORLD"
    
    def __init__(self, region: Region, population_size: int = 1000000):
        self.region = region
        self.population_size = population_size
        self._parameters = self._get_default_parameters()
    
    def _get_default_parameters(self) -> Dict[str, Any]:
        """Get default parameters for the region."""
        if self.region == self.Region.USA:
            return {
                "population_size": 330000000,  # Approximate US population
                "demographic_factors": {
                    "age_distribution": "census_2020",
                    "gender_distribution": {"male": 0.49, "female": 0.51},
                    "zipcode_distribution": "uniform"
                }
            }
        elif self.region == self.Region.EUROPE:
            return {
                "population_size": 750000000,  # Approximate EU population
                "demographic_factors": {
                    "age_distribution": "eurostat_2020",
                    "gender_distribution": {"male": 0.49, "female": 0.51},
                    "zipcode_distribution": "uniform"
                }
            }
        else:  # WORLD
            return {
                "population_size": 8000000000,  # Approximate world population
                "demographic_factors": {
                    "age_distribution": "world_bank_2020",
                    "gender_distribution": {"male": 0.50, "female": 0.50},
                    "zipcode_distribution": "uniform"
                }
            }
    
    @classmethod
    def create(cls, region: Region) -> 'ARXPopulationModel':
        """Create a population model for the specified region."""
        return cls(region)
    
    def get_population_size(self) -> int:
        """Get the population size."""
        return self._parameters["population_size"]
    
    def get_parameters(self) -> Dict[str, Any]:
        """Get all model parameters."""
        return self._parameters.copy()
