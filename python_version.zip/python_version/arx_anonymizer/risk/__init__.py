"""
Risk analysis module for ARX anonymization tool.
"""

import pandas as pd
import numpy as np
from typing import TYPE_CHECKING, Dict, List
from collections import Counter

if TYPE_CHECKING:
    from ..data import DataHandle
    from ..population_model import ARXPopulationModel


class AttackerRisk:
    """Risk metrics for a specific attacker model."""
    
    def __init__(self, records_at_risk: float, highest_risk: float, success_rate: float):
        self._records_at_risk = records_at_risk
        self._highest_risk = highest_risk
        self._success_rate = success_rate
    
    def get_records_at_risk(self) -> float:
        """Get the fraction of records at risk."""
        return self._records_at_risk
    
    def get_highest_risk(self) -> float:
        """Get the highest risk value."""
        return self._highest_risk
    
    def get_success_rate(self) -> float:
        """Get the attack success rate."""
        return self._success_rate


class RiskModelSampleSummary:
    """Summary of risk analysis results."""
    
    def __init__(self, prosecutor_risk: AttackerRisk, journalist_risk: AttackerRisk, marketer_risk: AttackerRisk):
        self._prosecutor_risk = prosecutor_risk
        self._journalist_risk = journalist_risk
        self._marketer_risk = marketer_risk
    
    def get_prosecutor_risk(self) -> AttackerRisk:
        """Get prosecutor attacker risk metrics."""
        return self._prosecutor_risk
    
    def get_journalist_risk(self) -> AttackerRisk:
        """Get journalist attacker risk metrics."""
        return self._journalist_risk
    
    def get_marketer_risk(self) -> AttackerRisk:
        """Get marketer attacker risk metrics."""
        return self._marketer_risk


class RiskEstimateBuilder:
    """Builder for risk estimates."""
    
    def __init__(self, data_handle: 'DataHandle', population_model: 'ARXPopulationModel'):
        self.data_handle = data_handle
        self.population_model = population_model
    
    def get_sample_based_risk_summary(self, threshold: float = 0.5) -> RiskModelSampleSummary:
        """Calculate sample-based risk summary."""
        data = self.data_handle.data
        
        # Calculate equivalence classes (groups of identical records)
        equivalence_classes = self._calculate_equivalence_classes(data)
        
        # Calculate risks for different attacker models
        prosecutor_risk = self._calculate_prosecutor_risk(equivalence_classes, threshold)
        journalist_risk = self._calculate_journalist_risk(equivalence_classes, threshold)
        marketer_risk = self._calculate_marketer_risk(equivalence_classes, threshold)
        
        return RiskModelSampleSummary(prosecutor_risk, journalist_risk, marketer_risk)
    
    def _calculate_equivalence_classes(self, data: pd.DataFrame) -> Dict[str, int]:
        """Calculate equivalence classes for the data."""
        # Convert rows to tuples for grouping
        row_tuples = [tuple(row) for row in data.values]
        return Counter(row_tuples)
    
        # // Init
        # double rA = 0d;
        # double rB = 0d;
        # double rC = 0d;
        # double numRecords = 0d;
        # double numClasses = 0d;
        # double smallestClassSize = Integer.MAX_VALUE;
        # int maxindex = sample.size();
        # int index = 0;
        
        # // For each group
        # Group<TupleWrapper> element = sample.first();
        # while (element != null) {
            
        #     // Track progress
        #     int prog = (int) Math.round(offset + (double) index++ / (double) maxindex * 3.3d);
        #     if (prog != progress.value) {
        #         progress.value = prog;
        #     }

        #     // Compute rA
        #     int groupSize = element.getCount();
        #     if (1d / groupSize > threshold) {
        #         rA += groupSize;
        #     }
        #     // Compute rB
        #     if (groupSize < smallestClassSize) {
        #         smallestClassSize = groupSize;
        #     }
        #     // Compute rC
        #     numClasses++;
        #     numRecords += groupSize;
    
        #     // Next element
        #     element = element.next();
            
        #     // Stop, if required
        #     if (stop.value) { throw new ComputationInterruptedException(); }
        # }
        
        # // Finalize rA
        # rA /= numRecords;
        
        # // Compute rB: smallest class is first class in the histogram
        # rB = 1d / smallestClassSize;

        # // Compute rC
        # rC = numClasses / numRecords;
        
        # // Return
        # return new ProsecutorRisk(threshold, rA, rB, rC);     
    def _calculate_prosecutor_risk(self, equivalence_classes: Dict, threshold: float) -> AttackerRisk:
        """Calculate prosecutor attacker risk (knows all attributes)."""
        total_records = sum(equivalence_classes.values())
        population_size = self.population_model.get_population_size()
        
        # Calculate risk for each equivalence class
        risks = []
        records_at_risk = 0
        
        for class_tuple, count in equivalence_classes.items():
            # Prosecutor risk: 1 / equivalence_class_size
            risk = 1.0 / count
            risks.append(risk)
            
            if risk > threshold:
                records_at_risk += count
        
        records_at_risk_ratio = records_at_risk / total_records if total_records > 0 else 0
        highest_risk = max(risks) if risks else 0        
        # Success rate estimation based on population model
        success_rate = min(total_records / population_size, 0.9)        
        return AttackerRisk(records_at_risk_ratio, highest_risk, success_rate)
    

    #     private JournalistRisk getJournalistRisk(Groupify<TupleWrapper> population,
    #                                          Groupify<TupleWrapper> sample,
    #                                          double offset,
    #                                          WrappedBoolean stop,
    #                                          WrappedInteger progress) {
    #     // Init
    #     double rA = 0d;
    #     double rB = 0d;
    #     double rC = 0d;
    #     double rC1 = 0d;
    #     double rC2 = 0d;
    #     double numRecordsInSample = 0d;
    #     double numClassesInSample = 0d;
    #     double smallestClassSizeInPopulation = Integer.MAX_VALUE;
    #     int maxindex = sample.size();
    #     int index = 0;
        
    #     // For each group
    #     Group<TupleWrapper> element = sample.first();
    #     while (element != null) {
            
    #         // Track progress
    #         int prog = (int) Math.round(offset + (double) index++ / (double) maxindex * 3.3d);
    #         if (prog != progress.value) {
    #             progress.value = prog;
    #         }
            
    #         // Process
    #         int groupSizeInSample = element.getCount();
    #         int groupSizeInPopulation = groupSizeInSample;
    #         if (population != sample) {
    #             groupSizeInPopulation = population.get(element.getElement()).getCount();
    #         }

    #         // Compute rA
    #         if (1d / groupSizeInPopulation > threshold) {
    #             rA += groupSizeInSample;
    #         }
    #         // Compute rB
    #         if (groupSizeInPopulation < smallestClassSizeInPopulation) {
    #             smallestClassSizeInPopulation = groupSizeInPopulation;
    #         }
    #         // Compute rC
    #         numClassesInSample++;
    #         numRecordsInSample += groupSizeInSample;
    #         rC1 += groupSizeInPopulation;
    #         rC2 += (double) groupSizeInSample / (double) groupSizeInPopulation;

    #         // Next element
    #         element = element.next();
            
    #         // Stop, if required
    #         if (stop.value) { throw new ComputationInterruptedException(); }
    #     }
        
    #     // Finalize rA
    #     rA /= numRecordsInSample;
        
    #     // Compute rB: smallest class is first class in the histogram
    #     rB = 1d / smallestClassSizeInPopulation;

    #     // Compute rC
    #     rC1 = numClassesInSample / rC1;
    #     rC2 = rC2 / numRecordsInSample;
    #     rC = Math.max(rC1,  rC2);
        
    #     // Return
    #     return new JournalistRisk(threshold, rA, rB, rC); 
    # }
    
    def _calculate_journalist_risk(self, equivalence_classes: Dict, threshold: float) -> AttackerRisk:
        """Calculate journalist attacker risk (knows some background information)."""
        total_records = sum(equivalence_classes.values())
        population_size = self.population_model.get_population_size()
        # Calculate risk for each equivalence class
        risks = []
        records_at_risk = 0
        for class_tuple, count in equivalence_classes.items():
            # Journalist risk: 1 / equivalence_class_size
            risk = 1.0 / count
            risks.append(risk)
            
            if risk > threshold:
                records_at_risk += count

        records_at_risk_ratio = records_at_risk / total_records if total_records > 0 else 0
        highest_risk = max(risks) if risks else 0

        # Success rate is lower than prosecutor
        success_rate = min(total_records / population_size * 0.933)

        return AttackerRisk(records_at_risk_ratio, highest_risk, success_rate)
    

    # private MarketerRisk getMarketerRisk(Groupify<TupleWrapper> population,
    #                                      Groupify<TupleWrapper> sample,
    #                                      double offset,
    #                                      WrappedBoolean stop,
    #                                      WrappedInteger progress) {

    #     // Init
    #     double rC = 0d;
    #     double numRecordsInSample = 0d;
    #     int maxindex = sample.size();
    #     int index = 0;
        
    #     // For each group
    #     Group<TupleWrapper> element = sample.first();
    #     while (element != null) {
            
    #         // Track progress
    #         int prog = (int) Math.round(offset + (double) index++ / (double) maxindex * 3.3d);
    #         if (prog != progress.value) {
    #             progress.value = prog;
    #         }
            
    #         // Process
    #         int groupSizeInSample = element.getCount();
    #         int groupSizeInPopulation = groupSizeInSample;
    #         if (population != sample) {
    #             groupSizeInPopulation = population.get(element.getElement()).getCount();
    #         }

    #         // Compute rC
    #         numRecordsInSample += groupSizeInSample;
    #         rC += (double) groupSizeInSample / (double) groupSizeInPopulation;

    #         // Next element
    #         element = element.next();
            
    #         // Stop, if required
    #         if (stop.value) { throw new ComputationInterruptedException(); }
    #     }

    #     // Compute rC
    #     rC = rC / numRecordsInSample;
        
    #     // Return
    #     return new MarketerRisk(rC); 
    # }
    
    def _calculate_marketer_risk(self, equivalence_classes: Dict, threshold: float) -> AttackerRisk:
        """Calculate marketer attacker risk (population-based attacks)."""
        total_records = sum(equivalence_classes.values())
        population_size = self.population_model.get_population_size()
        # Calculate risk for each equivalence class
        risks = []
        records_at_risk = 0
        for class_tuple, count in equivalence_classes.items():
            # Marketer risk: 1 / equivalence_class_size
            risk = 1.0 / count
            risks.append(risk)
            
            if risk > threshold:
                records_at_risk += count

        records_at_risk_ratio = records_at_risk / total_records if total_records > 0 else 0
        highest_risk = max(risks) if risks else 0

        # Success rate is lower than journalist
        success_rate = min(total_records / population_size * 0.966)

        return AttackerRisk(records_at_risk_ratio, highest_risk, success_rate)
