"""
ARX Data Anonymization Tool - Python Version
Copyright 2012 - 2022 Fabian Prasser and contributors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import sys
import os

# Add the parent directory to the path to import arx_anonymizer
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from arx_anonymizer import Data, ARXPopulationModel, Hierarchy


class Example43:
    """
    This class implements an example of how to evaluate combined risk metrics
    
    Ported from Java to Python
    """
    
    @staticmethod
    def main():
        """Entry point."""
        
        # Define data
        data = Data.create()
        data.add("age", "gender", "zipcode")
        data.add("45", "female", "81675")
        data.add("34", "male", "81667")
        data.add("66", "male", "81925")
        data.add("70", "female", "81931")
        data.add("34", "female", "81931")
        data.add("70", "male", "81931")
        data.add("45", "male", "81931")

        # Define hierarchies
        age = Hierarchy.create()
        age.add("34", "<50", "*")
        age.add("45", "<50", "*")
        age.add("66", ">=50", "*")
        age.add("70", ">=50", "*")

        gender = Hierarchy.create()
        gender.add("male", "*")
        gender.add("female", "*")

        # Only excerpts for readability
        zipcode = Hierarchy.create()
        zipcode.add("81667", "8166*", "816**", "81***", "8****", "*****")
        zipcode.add("81675", "8167*", "816**", "81***", "8****", "*****")
        zipcode.add("81925", "8192*", "819**", "81***", "8****", "*****")
        zipcode.add("81931", "8193*", "819**", "81***", "8****", "*****")

        data.get_definition().set_attribute_type("age", age)
        data.get_definition().set_attribute_type("gender", gender)
        data.get_definition().set_attribute_type("zipcode", zipcode)

        # Perform risk analysis
        print("\n - Input data")
        Example43.print_data(data.get_handle().get_view())
        print("\n - Risk analysis:")
        Example43.analyze_data(data.get_handle())
    
    @staticmethod
    def analyze_data(handle):
        """
        Perform risk analysis
        
        Args:
            handle: DataHandle to analyze
        """
        THRESHOLD = 0.5

        population_model = ARXPopulationModel.create(ARXPopulationModel.Region.USA)
        builder = handle.get_risk_estimator(population_model)
        risks = builder.get_sample_based_risk_summary(THRESHOLD)

        print(f" * Baseline risk threshold: {Example43.get_percent(THRESHOLD)}")
        print(" * Prosecutor attacker model")
        print(f"   - Records at risk: {Example43.get_percent(risks.get_prosecutor_risk().get_records_at_risk())}")
        print(f"   - Highest risk: {Example43.get_percent(risks.get_prosecutor_risk().get_highest_risk())}")
        print(f"   - Success rate: {Example43.get_percent(risks.get_prosecutor_risk().get_success_rate())}")
        print(" * Journalist attacker model")
        print(f"   - Records at risk: {Example43.get_percent(risks.get_journalist_risk().get_records_at_risk())}")
        print(f"   - Highest risk: {Example43.get_percent(risks.get_journalist_risk().get_highest_risk())}")
        print(f"   - Success rate: {Example43.get_percent(risks.get_journalist_risk().get_success_rate())}")
        print(" * Marketer attacker model")
        print(f"   - Success rate: {Example43.get_percent(risks.get_marketer_risk().get_success_rate())}")
    
    @staticmethod
    def get_percent(value: float) -> str:
        """
        Returns a formatted string
        
        Args:
            value: Value to format as percentage
            
        Returns:
            Formatted percentage string
        """
        return f"{int(round(value * 100))}%"
    
    @staticmethod
    def print_data(data_view):
        """
        Prints a given data view.
        
        Args:
            data_view: DataView to print
        """
        for row in data_view.iterator():
            print(f"   {row}")


if __name__ == "__main__":
    Example43.main()
