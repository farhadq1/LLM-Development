#!/usr/bin/env python3
"""
Script para demonstrar o ARX Python com dependências reais.
Execute apenas se as dependências estiverem instaladas.
"""

import sys
import os

def check_dependencies():
    """Verifica se as dependências estão disponíveis."""
    try:
        import pandas
        import numpy
        return True
    except ImportError:
        return False

def run_with_dependencies():
    """Executa o exemplo com dependências reais."""
    print("=== ARX Python com Dependências Reais ===\n")
    
    try:
        # Importa módulos locais
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        
        from arx_anonymizer.data import Data
        from arx_anonymizer.attribute_type import Hierarchy
        from arx_anonymizer.population_model import ARXPopulationModel
        
        print("1. Criando dados...")
        data = Data.create()
        data.add("age", "gender", "zipcode")
        data.add("45", "female", "81675")
        data.add("34", "male", "81667")
        data.add("66", "male", "81925")
        data.add("70", "female", "81931")
        data.add("34", "female", "81931")
        data.add("70", "male", "81931")
        data.add("45", "male", "81931")
        
        print("2. Definindo hierarquias...")
        age = Hierarchy.create()
        age.add("34", "<50", "*")
        age.add("45", "<50", "*")
        age.add("66", ">=50", "*")
        age.add("70", ">=50", "*")

        gender = Hierarchy.create()
        gender.add("male", "*")
        gender.add("female", "*")

        zipcode = Hierarchy.create()
        zipcode.add("81667", "8166*", "816**", "81***", "8****", "*****")
        zipcode.add("81675", "8167*", "816**", "81***", "8****", "*****")
        zipcode.add("81925", "8192*", "819**", "81***", "8****", "*****")
        zipcode.add("81931", "8193*", "819**", "81***", "8****", "*****")

        data.get_definition().set_attribute_type("age", age)
        data.get_definition().set_attribute_type("gender", gender)
        data.get_definition().set_attribute_type("zipcode", zipcode)
        
        print("3. Exibindo dados de entrada...")
        handle = data.get_handle()
        view = handle.get_view()
        for row in view.iterator():
            print(f"   {row}")
        
        print("\n4. Realizando análise de risco...")
        population_model = ARXPopulationModel.create(ARXPopulationModel.Region.USA)
        builder = handle.get_risk_estimator(population_model)
        risks = builder.get_sample_based_risk_summary(0.5)
        
        def get_percent(value):
            return f"{int(round(value * 100))}%"
        
        print(f"\n * Baseline risk threshold: {get_percent(0.5)}")
        print(" * Prosecutor attacker model")
        print(f"   - Records at risk: {get_percent(risks.get_prosecutor_risk().get_records_at_risk())}")
        print(f"   - Highest risk: {get_percent(risks.get_prosecutor_risk().get_highest_risk())}")
        print(f"   - Success rate: {get_percent(risks.get_prosecutor_risk().get_success_rate())}")
        print(" * Journalist attacker model")
        print(f"   - Records at risk: {get_percent(risks.get_journalist_risk().get_records_at_risk())}")
        print(f"   - Highest risk: {get_percent(risks.get_journalist_risk().get_highest_risk())}")
        print(f"   - Success rate: {get_percent(risks.get_journalist_risk().get_success_rate())}")
        print(" * Marketer attacker model")
        print(f"   - Success rate: {get_percent(risks.get_marketer_risk().get_success_rate())}")
        
        print("\n✅ Análise completa realizada com sucesso!")
        
    except Exception as e:
        print(f"❌ Erro na execução: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def main():
    """Função principal."""
    if check_dependencies():
        print("Dependências encontradas. Executando versão completa...")
        success = run_with_dependencies()
    else:
        print("Dependências não encontradas. Execute:")
        print("pip install pandas numpy scipy")
        print("\nExecutando teste básico...")
        import subprocess
        result = subprocess.run([sys.executable, "test_basic.py"], 
                              capture_output=True, text=True)
        print(result.stdout)
        if result.stderr:
            print("Erros:", result.stderr)
        success = result.returncode == 0
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
